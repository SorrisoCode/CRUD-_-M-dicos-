<?php
include("function.php");
index();
include HEADER_TEMPLATE;
?>

<header>
    <div class="row">
        <div class="col-sm-6">
            <h2>Médicos</h2>
        </div>

        <div class="col-sm-6 text-end h2">
            <a class="btn btn-secondary" href="add.php">
                <i class="fa-solid fa-user-plus"></i> Novo Médico
            </a>

            <a class="btn btn-light" href="index.php">
                <i class="fa-solid fa-refresh"></i> Atualizar
            </a>
        </div>
    </div>
</header>

<?php if (!empty($_SESSION['message'])): ?>
    <div class="alert alert-<?php echo $_SESSION['type']; ?> alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>

        <?php echo $_SESSION['message']; ?>
    </div>
<?php endif; ?>

<hr>
<div class="table-responsive">
    <table class="table table-hover">

        <thead>
            <tr>
                <th>ID</th>
                <th>Imagem</th>
                <th width="25%">Nome</th>
                <th>CRM</th>
                <th>Especialidade</th>
                <th>Telefone</th>
                <th>Atualizado em</th>
                <th>Opções</th>
            </tr>
        </thead>

        <tbody>

            <?php if ($doctors): ?>

                <?php foreach ($doctors as $doctor): ?>

                    <tr>

                        <td class="align-middle">
                            <?php echo $doctor['id']; ?>
                        </td>

                        <td class="align-middle">
                            <?php if (!empty($doctor['image'])): ?>

                                <a href="view.php?id=<?php echo $doctor['id']; ?>">
                                    <img src="img/<?php echo $doctor['image']; ?>" alt="<?php echo $doctor['name']; ?>" width="100"
                                        height="100" style="object-fit: cover; object-position: center 15%; border-radius: 5px;">
                                </a>

                            <?php endif; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo $doctor['name']; ?>
                        </td>

                        <td class="align-middle text-nowrap">
                            <?php echo $doctor['crm']; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo $doctor['specialty']; ?>
                        </td>

                        <td class="align-middle text-nowrap">
                            <?php echo telefone($doctor['phone']); ?>
                        </td>

                        <td class="align-middle text-nowrap">
                            <?php
                            $dt = new DateTime(
                                $doctor['modified'],
                                new DateTimeZone("America/Sao_Paulo")
                            );

                            echo $dt->format("d/m/Y - H:i:s");
                            ?>
                        </td>

                        <td class="actions text-end align-middle text-nowrap">

                            <a href="view.php?id=<?php echo $doctor['id']; ?>" class="btn btn-sm btn-light">
                                <i class="fa fa-eye"></i> Visualizar
                            </a>

                            <a href="edit.php?id=<?php echo $doctor['id']; ?>" class="btn btn-sm btn-secondary">
                                <i class="fa fa-pencil"></i> Editar
                            </a>

                            <a href="#" class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#delete-modal"
                                data-doctor="<?= $doctor['id']; ?>">
                                <i class="fa fa-trash"></i> Excluir
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="8">
                        Nenhum registro encontrado.
                    </td>
                </tr>

            <?php endif; ?>

        </tbody>

    </table>
</div>

<?php include "modal.php"; ?>

<?php include FOOTER_TEMPLATE; ?>