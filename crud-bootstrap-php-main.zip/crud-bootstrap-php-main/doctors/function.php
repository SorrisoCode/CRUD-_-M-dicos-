<?php
ob_start(); //output buffer aberto, para não dar erro de header location

include('../config.php');
include(DBAPI);

$doctors = null;
$doctor = null;

/**
 *  Formatar as datas
 */
function formatData($data, $formato)
{
	$dt = new Datetime($data, new DateTimeZone("America/Sao_Paulo"));// "-0300"
	return $dt->format($formato);
}

/**
 *  Formatar os telefones
 */
function telefone($tel)
{ //15999990000
	return "(" . substr($tel, 0, 2) . ")" . substr($tel, 2, 5)
		. "-" . substr($tel, 7, 4);
}

/**
 *  Formatar os cep´s
 */
function cep($cep)
{
	return substr($cep, 0, 5) . "-" . substr($cep, 5, 3);
}

/**
 *  Listagem de Médicos
 */
function index()
{
	global $doctors;
	$doctors = find_all("doctors");
}

/**
 *  Visualização de um Médico
 */
function view($id = null)
{
	global $doctor;
	$doctor = find('doctors', $id);
}

/**
 *  Cadastro de Médico
 */
function add()
{
	if (!empty($_POST['doctor'])) {

		$today = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));

		$doctor = $_POST['doctor'];

		if (isset($_FILES['doctor']['name']['image']) && $_FILES['doctor']['error']['image'] == 0) {

			$nomeImagem = basename($_FILES['doctor']['name']['image']);
			$caminhoImagem = __DIR__ . "/img/" . $nomeImagem;

			move_uploaded_file(
				$_FILES['doctor']['tmp_name']['image'],
				$caminhoImagem
			);

			$doctor['image'] = $nomeImagem;

		} else {

			$doctor['image'] = null;

		}

		$doctor['created'] = $today->format("Y-m-d H:i:s");
		$doctor['modified'] = $doctor['created'];

		save('doctors', $doctor);
		header('location: index.php');
	}
}

/**
 *	Atualizacao/Edicao de Médico
 */
function edit()
{
	$now = date_create('now', new DateTimeZone('America/Sao_Paulo'));

	if (isset($_GET['id'])) {

		$id = $_GET['id'];

		if (isset($_POST['doctor'])) {

			$doctor = $_POST['doctor'];

			$doctorAtual = find("doctors", $id);

			if (isset($_FILES['doctor']['name']['image']) && $_FILES['doctor']['error']['image'] == 0) {

				$nomeImagem = basename($_FILES['doctor']['name']['image']);
				$caminhoImagem = __DIR__ . "/img/" . $nomeImagem;

				move_uploaded_file(
					$_FILES['doctor']['tmp_name']['image'],
					$caminhoImagem
				);

				$doctor['image'] = $nomeImagem;

			} else {

				$doctor['image'] = $doctorAtual['image'];

			}

			$doctor['modified'] = $now->format("Y-m-d H:i:s");

			update("doctors", $id, $doctor);
			header("location: index.php");

		} else {

			global $doctor;
			$doctor = find("doctors", $id);
		}

	} else {
		header("location: index.php");
	}
}

/**
 *  Exclusão de um Médico
 */
function delete($id = null)
{
	global $doctor;
	remove('doctors', $id);

	header("location: index.php");
}

?>