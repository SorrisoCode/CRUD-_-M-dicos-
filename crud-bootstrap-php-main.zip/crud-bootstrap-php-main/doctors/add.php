<?php
include "function.php";
add();
include HEADER_TEMPLATE;
?>

<div class="container">

    <div class="col-md-8 mx-auto">

        <h2 style="text-align: center;">Novo Médico</h2>

        <hr>

        <form action="add.php" method="post" enctype="multipart/form-data">

            <div class="row g-3">

                <div class="form-group col-md-12">
                    <label for="name">Nome</label>
                    <input type="text" class="form-control" id="name" name="doctor[name]">
                </div>

                <div class="form-group col-md-6">
                    <label for="crm">CRM</label>
                    <input type="text" class="form-control" id="crm" name="doctor[crm]" maxlength="20">
                </div>

                <div class="form-group col-md-6">
                    <label for="birthdate">Data de Nascimento</label>
                    <input type="date" class="form-control" id="birthdate" name="doctor[birthdate]">
                </div>

                <div class="form-group col-md-12">
                    <label for="address">Endereço</label>
                    <input type="text" class="form-control" id="address" name="doctor[address]">
                </div>

                <div class="form-group col-md-6">
                    <label for="hood">Bairro</label>
                    <input type="text" class="form-control" id="hood" name="doctor[hood]">
                </div>

                <div class="form-group col-md-3">
                    <label for="zip_code">CEP</label>
                    <input type="text" class="form-control" id="zip_code" name="doctor[zip_code]" maxlength="8">
                </div>

                <div class="form-group col-md-3">
                    <label for="state">UF</label>
                    <input type="text" class="form-control" id="state" name="doctor[state]" maxlength="2">
                </div>

                <div class="form-group col-md-6">
                    <label for="city">Município</label>
                    <input type="text" class="form-control" id="city" name="doctor[city]">
                </div>

                <div class="form-group col-md-3">
                    <label for="phone">Telefone</label>
                    <input type="text" class="form-control" id="phone" name="doctor[phone]" maxlength="11">
                </div>

                <div class="form-group col-md-3">
                    <label for="mobile">Celular</label>
                    <input type="text" class="form-control" id="mobile" name="doctor[mobile]" maxlength="11">
                </div>

                <div class="form-group col-md-8">
                    <label for="specialty">Especialidade</label>
                    <input type="text" class="form-control" id="specialty" name="doctor[specialty]">
                </div>

                <div class="form-group col-md-4">
                    <label for="salary">Salário</label>
                    <input type="number" step="0.01" class="form-control" id="salary" name="doctor[salary]">
                </div>

                <div class="form-group col-md-8">
                    <label for="image">Imagem</label>
                    <input type="file" class="form-control" id="image" name="doctor[image]" accept="image/*">
                </div>

                <div class="form-group col-md-4">
                    <label for="created">Data de Cadastro</label>
                    <input type="date" class="form-control" id="created" name="doctor[created]">
                </div>

                <div class="form-group col-md-12">
                    <label for="description">Descrição</label>
                    <textarea class="form-control" id="description" name="doctor[description]" rows="3"></textarea>
                </div>

                <div class="form-group col-md-12 text-center">
                    <img id="preview" src="#" alt="Preview da imagem"
                        style="display: none; width: 150px; height: 150px; object-fit: contain; border-radius: 5px;">
                </div>

            </div>

            <br><br>

            <div id="actions" class="row">

                <div class="col-md-12 d-flex justify-content-end gap-2">

                    <a href="index.php" class="btn btn-light">
                        <i class="fa-solid fa-rotate-left"></i> Cancelar
                    </a>

                    <button type="submit" class="btn btn-secondary">
                        <i class="fa-solid fa-floppy-disk"></i> Salvar
                    </button>

                </div>

            </div>

        </form>

    </div>

</div>

<script>
    document.getElementById('image').addEventListener('change', function (event) {

        const file = event.target.files[0];
        const preview = document.getElementById('preview');

        if (file) {
            const reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'inline-block';
            };

            reader.readAsDataURL(file);
        } else {
            preview.src = '#';
            preview.style.display = 'none';
        }

    });
</script>

<?php include FOOTER_TEMPLATE; ?>