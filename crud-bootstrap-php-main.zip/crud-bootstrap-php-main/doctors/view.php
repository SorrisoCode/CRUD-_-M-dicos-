<?php
include('function.php');
view($_GET['id']);

include(HEADER_TEMPLATE);
?>

<div class="col-12 col-md-8 mx-auto text-center">

    <h2>Médico <?php echo $doctor['id']; ?></h2>
    <hr>

    <?php if (!empty($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['type']; ?>">
            <?php echo $_SESSION['message']; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($doctor['image'])): ?>
        <div class="text-center mb-4">
            <img src="img/<?php echo $doctor['image']; ?>" alt="<?php echo $doctor['name']; ?>" width="150" height="150"
                style="object-fit: cover; object-position: center 15%; border-radius: 5px;">
        </div>
    <?php endif; ?>

    <dl class="dl-horizontal text-center">
        <dt>Nome:</dt>
        <dd><?php echo $doctor['name']; ?></dd>

        <dt>CRM:</dt>
        <dd><?php echo $doctor['crm']; ?></dd>

        <dt>Data de Nascimento:</dt>
        <dd><?php echo formatData($doctor['birthdate'], "d/m/Y"); ?></dd>

        <dt>Especialidade:</dt>
        <dd><?php echo $doctor['specialty']; ?></dd>

        <dt>Salário:</dt>
        <dd>R$ <?php echo number_format($doctor['salary'], 2, ",", "."); ?></dd>
    </dl>

    <dl class="dl-horizontal text-center">
        <dt>Endereço:</dt>
        <dd><?php echo $doctor['address']; ?></dd>

        <dt>Bairro:</dt>
        <dd><?php echo $doctor['hood']; ?></dd>

        <dt>CEP:</dt>
        <dd><?php echo cep($doctor['zip_code']); ?></dd>

        <dt>Data de Cadastro:</dt>
        <dd><?php echo formatData($doctor['created'], "d/m/Y : H:i:s"); ?></dd>

        <dt>Data da última atualização:</dt>
        <dd><?php echo formatData($doctor['modified'], "d/m/Y - H:i:s"); ?></dd>
    </dl>

    <dl class="dl-horizontal text-center">
        <dt>Cidade:</dt>
        <dd><?php echo $doctor['city']; ?></dd>

        <dt>Telefone:</dt>
        <dd><?php echo telefone($doctor['phone']); ?></dd>

        <dt>Celular:</dt>
        <dd><?php echo telefone($doctor['mobile']); ?></dd>

        <dt>UF:</dt>
        <dd><?php echo $doctor['state']; ?></dd>

        <dt>Descrição:</dt>
        <dd><?php echo $doctor['description']; ?></dd>
    </dl>

    <div id="actions" class="row">
        <div class="col-md-12 d-flex justify-content-center gap-2">

            <a href="index.php" class="btn btn-light">
                <i class="fa-solid fa-arrow-rotate-left"></i> Voltar
            </a>

            <a href="edit.php?id=<?php echo $doctor['id']; ?>" class="btn btn-secondary">
                <i class="fa-solid fa-pen-to-square"></i> Editar
            </a>

        </div>
    </div>

</div>

<?php include FOOTER_TEMPLATE; ?>