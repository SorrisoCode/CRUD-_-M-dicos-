<?php
include "function.php";
edit();
include HEADER_TEMPLATE;
?>

<div class="container">

    <div class="col-md-8 mx-auto">

        <h2 style="text-align: center;">Atualizar Médico</h2>

        <hr>

        <form action="edit.php?id=<?= $doctor['id']; ?>" method="post" enctype="multipart/form-data">

            <div class="row g-3">

                <div class="form-group col-md-12">
                    <label for="name">Nome</label>
                    <input type="text" class="form-control" id="name" name="doctor[name]"
                        value="<?php echo $doctor['name']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="crm">CRM</label>
                    <input type="text" class="form-control" id="crm" name="doctor[crm]" maxlength="20"
                        value="<?php echo $doctor['crm']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="birthdate">Data de Nascimento</label>
                    <input type="date" class="form-control" id="birthdate" name="doctor[birthdate]"
                        value="<?php echo formatData($doctor['birthdate'], "Y-m-d"); ?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="address">Endereço</label>
                    <input type="text" class="form-control" id="address" name="doctor[address]"
                        value="<?php echo $doctor['address']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="hood">Bairro</label>
                    <input type="text" class="form-control" id="hood" name="doctor[hood]"
                        value="<?php echo $doctor['hood']; ?>">
                </div>

                <div class="form-group col-md-3">
                    <label for="zip_code">CEP</label>
                    <input type="text" class="form-control" id="zip_code" name="doctor[zip_code]" maxlength="8"
                        value="<?php echo $doctor['zip_code']; ?>">
                </div>

                <div class="form-group col-md-3">
                    <label for="state">UF</label>
                    <input type="text" class="form-control" id="state" name="doctor[state]" maxlength="2"
                        value="<?php echo $doctor['state']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="city">Município</label>
                    <input type="text" class="form-control" id="city" name="doctor[city]"
                        value="<?php echo $doctor['city']; ?>">
                </div>

                <div class="form-group col-md-3">
                    <label for="phone">Telefone</label>
                    <input type="text" class="form-control" id="phone" name="doctor[phone]" maxlength="11"
                        value="<?php echo $doctor['phone']; ?>">
                </div>

                <div class="form-group col-md-3">
                    <label for="mobile">Celular</label>
                    <input type="text" class="form-control" id="mobile" name="doctor[mobile]" maxlength="11"
                        value="<?php echo $doctor['mobile']; ?>">
                </div>

                <div class="form-group col-md-8">
                    <label for="specialty">Especialidade</label>
                    <input type="text" class="form-control" id="specialty" name="doctor[specialty]"
                        value="<?php echo $doctor['specialty']; ?>">
                </div>

                <div class="form-group col-md-4">
                    <label for="salary">Salário</label>
                    <input type="number" step="0.01" class="form-control" id="salary" name="doctor[salary]"
                        value="<?php echo $doctor['salary']; ?>">
                </div>

                <div class="form-group col-md-8">
                    <label for="image">Imagem</label>
                    <input type="file" class="form-control" id="image" name="doctor[image]" accept="image/*">
                </div>

                <div class="form-group col-md-4">
                    <label for="created">Data de Cadastro</label>
                    <input type="date" class="form-control" id="created" name="doctor[created]" disabled
                        value="<?php echo formatData($doctor['created'], "Y-m-d"); ?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="description">Descrição</label>
                    <textarea class="form-control" id="description" name="doctor[description]"
                        rows="3"><?php echo $doctor['description']; ?></textarea>
                </div>

                <div class="form-group col-md-12 text-center">

                    <?php if (!empty($doctor['image'])): ?>

                        <img id="preview" src="img/<?php echo $doctor['image']; ?>" alt="<?php echo $doctor['name']; ?>"
                            style="width: 150px; height: 150px; object-fit: cover; object-position: center 15%; border-radius: 5px;">

                    <?php else: ?>

                        <img id="preview" src="#" alt="Preview da imagem"
                            style="display: none; width: 150px; height: 150px; object-fit: cover; object-position: center 15%; border-radius: 5px;">

                    <?php endif; ?>

                </div>

            </div>

            <br><br>

            <div id="actions" class="row">
                <div class="col-md-12 d-flex justify-content-end gap-2">

                    <a href="index.php" class="btn btn-light">
                        <i class="fa-solid fa-rotate-left"></i> Cancelar
                    </a>

                    <button type="submit" class="btn btn-secondary">
                        <i class="fa-solid fa-floppy-disk"></i> Salvar
                    </button>

                </div>
            </div>

        </form>

    </div>

</div>

<script>
    document.getElementById('image').addEventListener('change', function (event) {

        const file = event.target.files[0];
        const preview = document.getElementById('preview');

        if (file) {
            const reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'inline-block';
            };

            reader.readAsDataURL(file);
        }

    });
</script>

<?php include FOOTER_TEMPLATE; ?>