SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET NAMES utf8;

CREATE DATABASE IF NOT EXISTS doctors_db;

USE doctors_db;

CREATE TABLE IF NOT EXISTS doctors (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  codigo INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  crm VARCHAR(20) NOT NULL,
  birthdate DATE NOT NULL,
  specialty VARCHAR(150) NOT NULL,
  description VARCHAR(250) NOT NULL,
  address VARCHAR(255) NOT NULL,
  hood VARCHAR(100) NOT NULL,
  zip_code INT(8) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  mobile VARCHAR(20) NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  image VARCHAR(100),
  created DATETIME NOT NULL,
  modified DATETIME NOT NULL
) DEFAULT CHARSET=utf8;

INSERT INTO doctors
(codigo, name, crm, birthdate, specialty, description, address, hood, zip_code, city, state, phone, mobile, salary, image, created, modified)
VALUES

(1001, 'Meredith Grey', 'CRM-1001', '2005-03-27', 'Cirurgia Geral', 'Médica especialista em Cirurgia Geral, com ampla experiência em procedimentos de alta complexidade e atendimento hospitalar.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1132457812', '11987654321', 25000.00, 'Meredith.jpeg', '2026-09-25 08:12:34', '2026-09-25 08:12:34'),
(1002, 'Derek Shepherd', 'CRM-1002', '2005-03-27', 'Neurocirurgia', 'Médico neurocirurgião com atuação em cirurgias cerebrais e tratamento de doenças do sistema nervoso central.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1143786295', '11974563218', 30000.00, 'Derek.jpeg', '2026-09-25 08:47:19', '2026-09-25 08:47:19'),
(1003, 'Cristina Yang', 'CRM-1003', '2005-03-27', 'Cirurgia Cardiovascular', 'Médica cardiologista cirúrgica especializada em intervenções cardiovasculares e acompanhamento de pacientes cardíacos.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1138674219', '11982367451', 28000.00, 'Cristina.jpeg', '2026-09-25 09:23:51', '2026-09-25 09:23:51'),
(1004, 'Miranda Bailey', 'CRM-1004', '2005-03-27', 'Cirurgia Geral', 'Médica especialista em Cirurgia Geral e gestão hospitalar, responsável pela coordenação de equipes médicas.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1145627831', '11993421876', 27000.00, 'Miranda.jpeg', '2026-09-25 10:05:27', '2026-09-25 10:05:27'),
(1005, 'Alex Karev', 'CRM-1005', '2005-03-27', 'Pediatria', 'Médico pediatra dedicado ao atendimento infantil, prevenção de doenças e acompanhamento do desenvolvimento infantil.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1137194856', '11965873214', 22000.00, 'Alex.jpeg', '2026-09-25 10:41:08', '2026-09-25 10:41:08'),
(1006, 'Richard Webber', 'CRM-1006', '2005-03-27', 'Cirurgia Geral', 'Médico cirurgião com extensa experiência clínica e atuação na formação e supervisão de profissionais da saúde.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1142865317', '11978124563', 32000.00, 'Richard.jpg', '2026-09-25 11:16:45', '2026-09-25 11:16:45'),
(1007, 'Arizona Robbins', 'CRM-1007', '2005-03-27', 'Cirurgia Pediátrica', 'Médica pediatra especializada em cirurgia pediátrica, com foco no tratamento cirúrgico de crianças e adolescentes.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1139547628', '11984621735', 29000.00, 'Arizona.jpg', '2026-09-25 13:08:32', '2026-09-25 13:08:32'),
(1008, 'Callie Torres', 'CRM-1008', '2005-03-27', 'Ortopedia', 'Médica ortopedista especialista em tratamento de lesões ósseas, articulares e reabilitação musculoesquelética.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1146318752', '11972541863', 28500.00, 'Callie.jpg', '2026-09-25 14:27:16', '2026-09-25 14:27:16'),
(1009, 'Jackson Avery', 'CRM-1009', '2005-03-27', 'Cirurgia Plástica', 'Médico cirurgião plástico com experiência em procedimentos reconstrutivos e estéticos de alta complexidade.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1137826495', '11991352748', 29500.00, 'Jackson.jpg', '2026-09-25 15:39:48', '2026-09-25 15:39:48'),
(1010, 'April Kepner', 'CRM-1010', '2005-03-27', 'Medicina de Emergência e Trauma', 'Médica especialista em Medicina de Emergência e Trauma, atuando no atendimento de pacientes em estado crítico.', 'Grey Sloan Memorial Hospital', 'Centro', 18000000, 'Seattle', 'WA', '1145196387', '11986734125', 26000.00, 'April.jpeg', '2026-09-25 16:52:21', '2026-09-25 16:52:21');


CREATE TABLE IF NOT EXISTS patients (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    codigo INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    birthdate DATE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    description VARCHAR(250),
    image VARCHAR(100)
);

INSERT INTO patients
(codigo, name, cpf, birthdate, phone, email, address, description, image)
VALUES

(1, 'Ana Souza', '123.456.789-00', '1990-05-12', '(15) 99999-1111', 'ana@email.com', 'Rua das Flores, 100', 'Paciente em acompanhamento', 'Souza.png'),
(2, 'Carlos Oliveira', '234.567.890-11', '1985-08-20', '(15) 98888-2222', 'carlos@email.com', 'Avenida Brasil, 250', 'Paciente regular', 'Oliveira.png'),
(3, 'Mariana Santos', '345.678.901-22', '1998-03-15', '(15) 97777-3333', 'mariana@email.com', 'Rua Central, 50', 'Primeira consulta', 'Santos.png'),
(4, 'João Pereira', '456.789.012-33', '1979-11-30', '(15) 96666-4444', 'joao@email.com', 'Rua São Paulo, 80', 'Paciente em acompanhamento', 'Pereira.png'),
(5, 'Beatriz Costa', '567.890.123-44', '2001-07-25', '(15) 95555-5555', 'beatriz@email.com', 'Avenida Paulista, 120', 'Paciente regular', 'Costa.png'),
(6, 'Lucas Almeida', '678.901.234-55', '1993-02-18', '(15) 94444-6666', 'lucas@email.com', 'Rua das Palmeiras, 45', 'Paciente novo', 'Almeida.png'),
(7, 'Juliana Martins', '789.012.345-66', '1988-09-10', '(15) 93333-7777', 'juliana@email.com', 'Rua do Comércio, 200', 'Paciente regular', 'Martins.png'),
(8, 'Rafael Lima', '890.123.456-77', '1995-12-05', '(15) 92222-8888', 'rafael@email.com', 'Avenida Central, 310', 'Paciente em acompanhamento', 'Lima.png'),
(9, 'Camila Rodrigues', '901.234.567-88', '2000-04-22', '(15) 91111-9999', 'camila@email.com', 'Rua das Acácias, 75', 'Primeira consulta', 'Rodrigues.png'),
(10, 'Gabriel Ferreira', '012.345.678-99', '1982-06-14', '(15) 90000-0000', 'gabriel@email.com', 'Rua Independência, 150', 'Paciente regular', 'Ferreira.png');