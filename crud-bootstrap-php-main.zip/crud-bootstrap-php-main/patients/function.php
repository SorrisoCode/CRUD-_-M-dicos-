<?php
ob_start(); //output buffer aberto, para não dar erro de header location

include('../config.php');
include(DBAPI);

$patients = null;
$patient = null;

/**
 *  Formatar as datas
 */
function formatData($data, $formato)
{
  $dt = new Datetime($data, new DateTimeZone("America/Sao_Paulo"));// "-0300"
  return $dt->format($formato);
}

/**
 *  Formatar os telefones
 */
function telefone($tel)
{ //15999990000
  return "(" . substr($tel, 0, 2) . ")" . substr($tel, 2, 5)
    . "-" . substr($tel, 7, 4);
}

/*
 *	Formatar cpf
 */
function formataCPF($cpf)
{
  // 12345678901

  return substr($cpf, 0, 3) . "." . substr($cpf, 3, 3)
    . "." . substr($cpf, 6, 3) . "-" . substr($cpf, 9, 2);
}

/**
 *  Formatar os cep´s
 */
function cep($cep)
{
  return substr($cep, 0, 5) . "-" . substr($cep, 5, 3);
}

/**
 *  Listagem de Pacientes
 */
function index()
{
  global $patients;
  $patients = find_all("patients");
  //find_all e find é a mesma coisa, resulta na mesma coisa
}

/**
 *  Visualização de um Paciente
 */
function view($id = null)
{
  global $patient;
  $patient = find('patients', $id);
}

/**
 *  Cadastro de Pacientes
 */
/**
 *  Cadastro de Pacientes
 */
function add()
{
  if (!empty($_POST['patient'])) {

    $patient = $_POST['patient'];

    if (isset($_FILES['patient']['name']['image']) && $_FILES['patient']['error']['image'] == 0) {

      $nomeImagem = basename($_FILES['patient']['name']['image']);
      $caminhoImagem = __DIR__ . "/img/" . $nomeImagem;

      move_uploaded_file(
        $_FILES['patient']['tmp_name']['image'],
        $caminhoImagem
      );

      $patient['image'] = $nomeImagem;

    } else {

      $patient['image'] = null;

    }

    save('patients', $patient);

    header('location: index.php');
  }
}

/**
 *	Atualizacao/Edicao de Paciente
 */
function edit()
{

  if (isset($_GET['id'])) {

    $id = $_GET['id'];

    if (isset($_POST['patient'])) {

      $patient = $_POST['patient'];

      update("patients", $id, $patient);
      header("location: index.php");
    } else {

      global $patient;
      $patient = find("patients", $id);
    }
  } else {
    header("location: index.php");
  }
}

/**
 *  Exclusão de um Paciente
 */
function delete($id = null)
{
  global $patient;

  remove("patients", $id);

  header("location: index.php");
}

?>