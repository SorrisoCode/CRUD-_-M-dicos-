<?php
include("function.php");
view($_GET['id']);
include HEADER_TEMPLATE;
?>

<div class="container">

    <div class="col-md-8 mx-auto text-center">

        <h2>Paciente <?php echo $patient['id']; ?></h2>

        <hr>

        <?php if (!empty($patient['image'])): ?>

            <div class="mb-4">
                <img src="img/<?php echo $patient['image']; ?>" alt="<?php echo $patient['name']; ?>"
                    style="width: 150px; height: 150px; object-fit: contain; border-radius: 5px;">
            </div>

        <?php endif; ?>

        <div class="text-center">

            <div class="mb-3">
                <strong>Nome:</strong>
                <div><?php echo $patient['name']; ?></div>
            </div>

            <div class="mb-3">
                <strong>CPF:</strong>
                <div><?php echo $patient['cpf']; ?></div>
            </div>

            <div class="mb-3">
                <strong>Data de Nascimento:</strong>
                <div><?php echo formatData($patient['birthdate'], "d/m/Y"); ?></div>
            </div>

            <div class="mb-3">
                <strong>Telefone:</strong>
                <div><?php echo $patient['phone']; ?></div>
            </div>

            <div class="mb-3">
                <strong>E-mail:</strong>
                <div><?php echo $patient['email']; ?></div>
            </div>

            <div class="mb-3">
                <strong>Endereço:</strong>
                <div><?php echo $patient['address']; ?></div>
            </div>

            <div class="mb-4">
                <strong>Descrição:</strong>
                <div><?php echo $patient['description']; ?></div>
            </div>

        </div>

        <div id="actions" class="row">

            <div class="col-md-12 d-flex justify-content-center gap-2">

                <a href="index.php" class="btn btn-light">
                    <i class="fa-solid fa-arrow-rotate-left"></i> Voltar
                </a>

                <a href="edit.php?id=<?php echo $patient['id']; ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-pen-to-square"></i> Editar
                </a>

            </div>

        </div>

    </div>

</div>

<?php include FOOTER_TEMPLATE; ?>