<?php
include("function.php");
index();
include HEADER_TEMPLATE;
?>

<header>
    <div class="row">
        <div class="col-sm-6">
            <h2>Pacientes</h2>
        </div>

        <div class="col-sm-6 text-end h2">
            <a href="add.php" onclick="window.location.href='add.php'; return false;" class="btn btn-secondary">
                <i class="fa-solid fa-user-plus"></i> Novo Paciente
            </a>

            <a class="btn btn-light" href="index.php">
                <i class="fa-solid fa-refresh"></i> Atualizar
            </a>
        </div>
    </div>
</header>

<?php if (!empty($_SESSION['message'])): ?>
    <div class="alert alert-<?php echo $_SESSION['type']; ?> alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>

        <?php echo $_SESSION['message']; ?>
    </div>
<?php endif; ?>

<hr>

<div class="table-responsive">

    <table class="table table-hover">

        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">Imagem</th>
                <th class="text-center">Nome</th>
                <th class="text-center">CPF</th>
                <th class="text-center">Telefone</th>
                <th class="text-center">Data de Nascimento</th>
                <th class="text-center">Opções</th>
            </tr>
        </thead>

        <tbody>

            <?php if ($patients): ?>

                <?php foreach ($patients as $patient): ?>

                    <tr>

                        <td class="align-middle text-center">
                            <?php echo $patient['id']; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php if (!empty($patient['image'])): ?>

                                <a href="view.php?id=<?php echo $patient['id']; ?>">
                                    <img src="img/<?php echo $patient['image']; ?>" alt="<?php echo $patient['name']; ?>"
                                        width="100" height="100"
                                        style="object-fit: cover; object-position: center 25%; border-radius: 5px;">
                                </a>

                            <?php endif; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo $patient['name']; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo $patient['cpf']; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo $patient['phone']; ?>
                        </td>

                        <td class="align-middle text-center">
                            <?php echo formatData($patient['birthdate'], "d/m/Y"); ?>
                        </td>

                        <td class="actions align-middle text-center text-nowrap">

                            <a href="view.php?id=<?php echo $patient['id']; ?>" class="btn btn-sm btn-light">
                                <i class="fa fa-eye"></i> Visualizar
                            </a>

                            <a href="edit.php?id=<?php echo $patient['id']; ?>" class="btn btn-sm btn-secondary">
                                <i class="fa fa-pencil"></i> Editar
                            </a>

                            <a href="#" class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#delete-modal"
                                data-patient="<?= $patient['id']; ?>">
                                <i class="fa fa-trash"></i> Excluir
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="7" class="text-center">
                        Nenhum registro encontrado.
                    </td>
                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>

<?php include "modal.php"; ?>

<?php include FOOTER_TEMPLATE; ?>