<?php
include "function.php";
edit();
include HEADER_TEMPLATE;
?>

<div class="container">

    <div class="col-md-8 mx-auto">

        <h2 style="text-align: center;">Atualizar Paciente</h2>

        <hr>

        <form action="edit.php?id=<?= $patient['id']; ?>" method="post" enctype="multipart/form-data">

            <div class="row g-3">

                <div class="form-group col-md-3">
                    <label for="codigo">Código</label>
                    <input type="text" class="form-control" id="codigo" name="patient[codigo]"
                        value="<?php echo $patient['codigo']; ?>">
                </div>

                <div class="form-group col-md-9">
                    <label for="name">Nome</label>
                    <input type="text" class="form-control" id="name" name="patient[name]"
                        value="<?php echo $patient['name']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" id="cpf" name="patient[cpf]" maxlength="14"
                        value="<?php echo $patient['cpf']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="birthdate">Data de Nascimento</label>
                    <input type="date" class="form-control" id="birthdate" name="patient[birthdate]"
                        value="<?php echo formatData($patient['birthdate'], "Y-m-d"); ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="phone">Telefone</label>
                    <input type="text" class="form-control" id="phone" name="patient[phone]" maxlength="20"
                        value="<?php echo $patient['phone']; ?>">
                </div>

                <div class="form-group col-md-6">
                    <label for="email">E-mail</label>
                    <input type="email" class="form-control" id="email" name="patient[email]"
                        value="<?php echo $patient['email']; ?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="address">Endereço</label>
                    <input type="text" class="form-control" id="address" name="patient[address]"
                        value="<?php echo $patient['address']; ?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="description">Descrição</label>
                    <input type="text" class="form-control" id="description" name="patient[description]"
                        value="<?php echo $patient['description']; ?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="image">Imagem</label>

                    <input type="file" class="form-control" id="image" name="patient[image]" accept="image/*">
                </div>

                <div class="form-group col-md-12 text-center">

                    <?php if (!empty($patient['image'])): ?>

                        <img id="preview" src="img/<?php echo $patient['image']; ?>" alt="<?php echo $patient['name']; ?>"
                            style="width: 150px; height: 150px; object-fit: contain; border-radius: 5px;">

                    <?php else: ?>

                        <img id="preview" src="#" alt="Preview da imagem"
                            style="display: none; width: 150px; height: 150px; object-fit: contain; border-radius: 5px;">

                    <?php endif; ?>

                </div>

            </div>

            <br><br>

            <div id="actions" class="row">

                <div class="col-md-12 d-flex justify-content-end gap-2">

                    <a href="index.php" class="btn btn-light">
                        <i class="fa-solid fa-rotate-left"></i> Cancelar
                    </a>

                    <button type="submit" class="btn btn-secondary">
                        <i class="fa-solid fa-floppy-disk"></i> Salvar
                    </button>

                </div>

            </div>

        </form>

    </div>

</div>

<script>
    document.getElementById('image').addEventListener('change', function (event) {

        const file = event.target.files[0];
        const preview = document.getElementById('preview');

        if (file) {

            const reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'inline-block';
            };

            reader.readAsDataURL(file);

        }

    });
</script>

<?php include FOOTER_TEMPLATE; ?>