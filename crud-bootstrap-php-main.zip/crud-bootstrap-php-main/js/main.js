/**
 * Passa os dados do paciente para o Modal, e atualiza o link para exclusão
 */
$('#delete-modal').on('show.bs.modal', function (event) {
  
  var button = $(event.relatedTarget);
  var id = button.data('patient');
  
  var modal = $(this); // this -> indica o modal que está sendo aberto
  modal.find('.modal-title').text('Excluir Paciente #' + id);
  modal.find('#confirm').attr('href', 'delete.php?id=' + id);
})