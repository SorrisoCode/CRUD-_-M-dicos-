<?php
include 'config.php';
include DBAPI;

include HEADER_TEMPLATE;

$erro = null;

try {
	$db = open_database();
} catch (Exception $e) {
	$erro = $e->getMessage();
}
?>

<main class="d-flex flex-column justify-content-center">

	<h1 class="text-center">Página Inicial</h1>

	<hr>

	<?php if (!$erro): ?>

		<div class="row justify-content-center text-center g-3">

			<div class="col-6 col-sm-3 col-md-3 col-xl-2">
				<a href="patients/add.php" class="btn btn-secondary w-100">
					<i class="fa-solid fa-user-plus fa-5x"></i>
					<p>Novo Paciente</p>
				</a>
			</div>

			<div class="col-6 col-sm-3 col-md-3 col-xl-2">
				<a href="patients" class="btn btn-secondary w-100">
					<i class="fa fa-user-group fa-5x"></i>
					<p>Pacientes</p>
				</a>
			</div>

			<div class="col-6 col-sm-3 col-md-3 col-xl-2">
				<a href="doctors/add.php" class="btn btn-secondary w-100">
					<i class="fa-solid fa-user-doctor fa-5x"></i>
					<p>Novo Médico</p>
				</a>
			</div>

			<div class="col-6 col-sm-3 col-md-3 col-xl-2">
				<a href="doctors" class="btn btn-secondary w-100">
					<i class="fa-solid fa-user-nurse fa-5x"></i>
					<p>Médicos</p>
				</a>
			</div>

		</div>

	<?php else: ?>

		<div class="alert alert-danger" role="alert">
			<p>
				<b>ERRO:</b> Não foi possível Conectar ao Banco de Dados!<br>
				<?= $erro ?>
			</p>
		</div>

	<?php endif; ?>

</main>

<?php include FOOTER_TEMPLATE; ?>