<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <title>Hospital</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" type="image/png" href="img/icon.png">
    <link rel="stylesheet" href="<?php echo BASEURL; ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo BASEURL; ?>css/estilo.css">
    <link rel="stylesheet" href="<?php echo BASEURL; ?>css/all.min.css">

    <style>
        body {
            margin-top: 1.5rem;
            padding-top: 50px;
            padding-bottom: 20px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top container-fluid px-lg-5 px-3" data-bs-theme="dark">

        <div class="container-fluid">

            <!-- Casa + Logo -->
            <a class="navbar-brand" href="<?php echo BASEURL; ?>index.php">
                <i class="fa-solid fa-house-chimney"></i>
                <img src="<?php echo BASEURL; ?>img/logo.png" alt="Logo">
            </a>

            <!-- Botão mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Menu -->
            <div class="collapse navbar-collapse" id="navbarNavDropdown">

                <ul class="navbar-nav ms-auto">

                    <!-- Pacientes -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="fa-solid fa-user-group"></i> Pacientes
                        </a>

                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?php echo BASEURL; ?>patients/index.php">
                                    Pacientes
                                </a>
                            </li>

                            <li>
                                <a class="dropdown-item" href="<?php echo BASEURL; ?>patients/add.php">
                                    Novo Paciente
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- Médicos -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="fa-solid fa-user-doctor"></i> Médicos
                        </a>

                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="<?php echo BASEURL; ?>doctors/index.php">
                                    Médicos
                                </a>
                            </li>

                            <li>
                                <a class="dropdown-item" href="<?php echo BASEURL; ?>doctors/add.php">
                                    Novo Médico
                                </a>
                            </li>
                        </ul>
                    </li>

                </ul>

            </div>

        </div>

    </nav>

    <main class="container">