<hr>
</main> <!-- /container -->

<footer class="footer" id="sec-info">

    <div class="footer-top">

        <div class="footer-logo">
            <img src="img/logo.png" alt="logo">
        </div>

        <div class="footer-info">
            <h4>Cadastros dos Médicos</h4>
        </div>

    </div>

    <hr>

    <div class="footer-bottom">
        <?php $dt = new DateTime("now", new DateTimeZone("America/Sao_Paulo")); ?>
        © Ayram Almeida e Beatriz Vasconcelos - 2026 à <?= $dt->format("Y") ?>
    </div>

</footer>

<script src="<?php echo BASEURL; ?>js/jquery-4.0.0.min.js"></script>
<script src="<?php echo BASEURL; ?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASEURL; ?>js/all.min.js"></script>
<script src="<?php echo BASEURL; ?>js/main.js"></script>

</body>

</html>